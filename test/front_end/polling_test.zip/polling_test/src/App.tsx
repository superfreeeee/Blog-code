import React from 'react'
import List from './List'

export default function App() {
  return <List />
}
